import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Create a new class named Recipe, which represents a type of food you can prepare.
 * 
 * @author kevindichter
 *
 */
public class Recipe implements Comparable<Recipe>{
	
	private String name;
	private String category;
	private Set<Ingredient> ingredients;
	private List<String> instructions;
	
	/**
	 * Creates a new Recipe object.
	 * 
	 * @param name Name of the recipe
	 * @param category Category of the recipe
	 */
	public Recipe(String name, String category) {
		this.name = name;
		this.category = category;
		ingredients = new TreeSet<>();
		instructions = new ArrayList<>();
	}
	
	/**
	 * Gets the name.
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Gets the category.
	 * 
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	
	/**
	 * Receives an Ingredient object and adds it to the ingredients collection.
	 * 
	 * @param ingredient Ingredient to be added to the ingredients list
	 */
	public void addIngredient(Ingredient ingredient) {
		ingredients.add(ingredient);
	}
	
	/**
	 * receives a String and adds it to the end of the collection of instructions.

	 * @param step Step to be added to the instructions list
	 */
	public void addStep(String step) {
		instructions.add(step);
	}
	
	/**
	 * Adds the String to the collection of instructions, before the step whose index is the int. 
	 * 
	 * @param step Step to be added
	 * @param index Index in which to add the step
	 */
	public void insertStep(String step, int index) {
		instructions.add(index, step);
	}
	
	/**
	 * Returns the total calories for the recipe.
	 * 
	 * @return the total calories for the recipe
	 */
	public double getTotalCalories() {
		double total = 0;
		for(Ingredient ingredient: ingredients) {
			total += ingredient.getQuantity() * ingredient.getCalories();
		}
		return total;
	}
	
	/**
	 * Returns a new Recipe with the same steps and ingredients, except that the quantity of every ingredient has been doubled.
	 * 
	 * @return a new Recipe with the same steps and ingredients, except that the quantity of every ingredient has been doubled.
	 */
	public Recipe getDoubled() {
		Recipe doubled = new Recipe(this.name, this.category);
		doubled.instructions.addAll(instructions);
		for(Ingredient ingredient : ingredients) {
			doubled.addIngredient(new Ingredient(ingredient.getQuantity() * 2, ingredient.getUnit(),
					ingredient.getType(), ingredient.getCalories()));
		}
		return doubled;
	}
	
	/**
	 * Receives a set of ingredients representing all of the foodstuffs that the user has in their house.
	 * 
	 * @param pantry Set of ingredients
	 * @return true or false whether or not the user can make the recipe
	 */
	public boolean canMake(Set<Ingredient> pantry) {
		/*
		if(!pantry.containsAll(ingredients)) {
			return false;
		}
		*/
		int countIngredients = 0;
		for(Ingredient ingredient : ingredients) {
			for(Ingredient other : pantry) {
				if(ingredient.getType().equals(other.getType()) && ingredient.getUnit().equals(other.getUnit())) {
					countIngredients++;
					if(other.compareTo(ingredient) < 0) {
						return false;
					}
				}
			}
		}
		if(countIngredients == ingredients.size()) {
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		String beginning = "Name: " + name + "\nCategory: " + category;
		
		String middle = "\n\n\tIngredients:";
		for(Ingredient ingredient : ingredients) {
			middle = middle + "\n" + ingredient;
		}
		
		String end = "\n\n\tInstructions:";
		int count = 0;
		for(String step : instructions) {
			end = end + "\n" + count + ": " + step;
			count++;
		}
		return beginning + middle + end + "\n";
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		Recipe other = (Recipe)obj;
		if(!name.equals(other.name) || !category.equals(other.category)) {
			return false;
		}
		return true;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode() * 2 + category.hashCode() * 4;
	}
	
	@Override
	public int compareTo(Recipe other) {
		int result = category.compareTo(other.category);
		if(result == 0) {
			result = name.compareTo(other.name);
		}
		return result;
	}
	
	
	
}
