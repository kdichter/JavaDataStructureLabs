import java.util.Random;
import java.util.Scanner;
/**
 * Create a 2D array of dashes and hashtags.
 * @author kevindichter
 * @date 08/24
 * CSCI 162
 */
public class Life {
	/**
	 * Take input from user and send it into methods.
	 * @param args
	 */

	public static void main(String[] args) {	
		Scanner reader = new Scanner(System.in);
		//System.out.print("Enter the number of rows in the matrix: ");
		int rows = reader.nextInt();
		//System.out.print("Enter the number of columns in the matrix: ");
		int cols = reader.nextInt();
		//System.out.print("Enter the seed for the randomness: ");
		long seed = reader.nextLong();
		//long seed = 7L;
		
		//creates boolean array with values specified by user
		boolean [][] matrix = new boolean[rows][cols];
		
		booleanMatrix(matrix, seed);
		printMatrix(matrix);
 	}
	/**
	 * Assigns random values in the 2D array to true based on the seed.
	 * @param matrix 2D array with starting with all false values
	 * @param seed seed to determine random true values in the matrix
	 */
	public static void booleanMatrix(boolean [][] matrix, long seed) {
		Random random = new Random(seed);
		
		for(int r = 1; r < matrix.length - 1; r++) {
			for(int c = 1; c < matrix[r].length - 1; c++) {
				matrix[r][c] = random.nextBoolean();
			}
		}
	}
	/**
	 * Prints out the matrix 2D array converting true and false values to "-" or "#".
	 * @param matrix 2D array with random true and false values
	 */
	public static void printMatrix(boolean [][]matrix) {
		for(int r = 0; r < matrix.length; r++) {
			for(int c = 0; c < matrix[r].length; c++) {
				if(matrix[r][c] == false) {
					System.out.print("- ");
				}
				else {
					System.out.print("# ");
				}
			}
			System.out.println();	
		}
	}

}
