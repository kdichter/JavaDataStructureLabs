import java.util.Random;
import java.util.Scanner;
/**
 * Create a 2D array of dashes and hashtags.
 * @author kevindichter
 * @date 08/24
 * CSCI 162
 */
public class Life {
	/**
	 * Take input from user and send it into methods.
	 * @param args
	 */

	public static void main(String[] args) {	
		Scanner reader = new Scanner(System.in);
		//System.out.print("Enter the number of rows in the matrix: ");
		int rows = reader.nextInt();
		//System.out.print("Enter the number of columns in the matrix: ");
		int cols = reader.nextInt();
		//System.out.print("Enter the seed for the randomness: ");
		long seed = reader.nextLong();
		//long seed = 7L;
		int birthLow = reader.nextInt();
		int birthHigh = reader.nextInt();
		int liveLow = reader.nextInt();
		int liveHigh = reader.nextInt();
		
		//creates boolean array with values specified by user
		boolean [][] matrix = new boolean[rows][cols];
		booleanMatrix(matrix, seed);
		boolean [][] newGen = booleanMatrixCopy(matrix);
		printMatrix(matrix);
		System.out.println();
		
		/*
		 6
		 8
		 7
		 3
		 8
		 3
		 8 
		 */
		for(int i = 0; i < 5; i++) {
			newGen = newGeneration(newGen, birthLow, birthHigh, liveLow, liveHigh);
			printMatrix(newGen);
			System.out.println();
		}

 	}
	/**
	 * Assigns random values in the 2D array to true based on the seed.
	 * @param matrix 2D array with starting with all false values
	 * @param seed seed to determine random true values in the matrix
	 */
	public static void booleanMatrix(boolean [][] matrix, long seed) {
		Random random = new Random(seed);
		
		for(int r = 1; r < matrix.length - 1; r++) {
			for(int c = 1; c < matrix[r].length - 1; c++) {
				matrix[r][c] = random.nextBoolean();
			}
		}
	}
	/**
	 * Creates a copy of the matrix 2D array.
	 * @param matrix 2D array to be copied
	 * @return 2D array copy of the parameter array
	 */
	public static boolean[][] booleanMatrixCopy(boolean [][] matrix) {
		boolean [][] copy = new boolean[matrix.length][matrix[0].length];
		for(int r = 0; r < matrix.length; r++) {
			for(int c = 0; c < matrix[r].length; c++) {
				copy[r][c] = matrix[r][c];
			}
		}
		return copy;
	}
	/**
	 * Takes an old generation 2D and converts it to the new generation array.
	 * @param matrix New generation of 2D matrix array
	 * @param birthLow Low birth rate requirement
	 * @param birthHigh High birth rate requirement
	 * @param liveLow Low live rate requirement
	 * @param liveHigh High live rate requirement
	 * @return New 2D array of new generation
	 */
	public static boolean [][] newGeneration(boolean [][] matrix, int birthLow, int birthHigh, int liveLow, int liveHigh) {
		int neighbors;
		boolean [][] copy = booleanMatrixCopy(matrix);
		for(int r = 1; r < matrix.length - 1; r++) {
			for(int c = 1; c < matrix[r].length - 1; c++) {
				neighbors = 0;
				//Loops through to check neighbors
				for(int i = -1; i < 2; i++) {
					for(int j = -1; j < 2; j++) {
						if(matrix[r + i][c + j] == true) neighbors++;
					}
				}
				//System.out.println("rows is " + r + " cols is " + c + "neighbors is " + neighbors);
				//System.out.println("///////////////////");
				//kills or births cell
				if(matrix[r][c] == false && (neighbors >= birthLow && neighbors <= birthHigh)) {
					copy[r][c] = true;
				}
				if(matrix[r][c] == true && (neighbors < liveLow || neighbors > liveHigh)) {
					copy[r][c] = false;
				}
			}
		}
		return copy;
	}
	/**
	 * Prints out the matrix 2D array converting true and false values to "-" or "#".
	 * @param matrix 2D array with random true and false values
	 */
	public static void printMatrix(boolean [][]matrix) {
		for(int r = 0; r < matrix.length; r++) {
			for(int c = 0; c < matrix[r].length; c++) {
				if(matrix[r][c] == false) {
					System.out.print("- ");
				}
				else {
					System.out.print("# ");
				}
			}
			System.out.println();	
		}
	}

}
