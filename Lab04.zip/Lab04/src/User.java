import java.util.ArrayList;

/**
 * Create a new class named User that will represent a person who has permission to use our system.
 * 
 * @author kevindichter
 *
 */
public class User {
	
	private String userName;
	private ArrayList<String> groups;
	
	/**
	 * Constructs a new User object.
	 * 
	 * @param userName Username of user
	 */
	public User(String userName) {
		this.userName = userName;
		groups = new ArrayList<>();
	}
	/**
	 * Gets the username.
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * Receives the name of a group and returns whether or not the user is a member of that group.
	 *  
	 * @param group Group that user might belong to
	 * @return Whether or not the user belongs to the group
	 */
	public boolean isInGroup(String group) {
		return groups.contains(group);
	}
	/**
	 * receives the name of a group and adds it to the collection of groups the user belongs to.
	 * 
	 * @param group Group to be added to groups if possible
	 */
	public void addToGroup(String group){
		if(!groups.contains(group)) {
			groups.add(group);
		}
	}
	/**
	 * receives the name of a group and removes it from the collection of groups the user belongs to.
	 * 
	 * @param group Group to be removed from groups if possible
	 */
	public void removeFromGroup(String group) {
		if(groups.indexOf(group) != -1) {
			groups.remove(groups.indexOf(group));
		}
	}
	@Override
	public String toString() {
		if(groups.size() == 0) {
			return userName + " is a member of no groups.";
		}
		return userName + " is a member of " + groups.toString() + ".";
		
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		User other = (User)obj;
		if(!userName.equals(other.userName)) {
			return false;  
		}
		if(!groups.equals(other.groups)) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return userName.hashCode() * 2 + groups.hashCode() * 4;
	}
	
}
