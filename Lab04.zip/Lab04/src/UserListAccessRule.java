import java.util.ArrayList;

/**
 * Create a new class named UserListAccessRule, which represents a rule that says only people with certain usernames may have access to a resource.
 * 
 * @author kevindichter
 *
 */
public class UserListAccessRule implements AccessRule{
	private ArrayList<String> userNames;
	
	/**
	 * Constructs a new UserListAccessRule object.
	 */
	public UserListAccessRule() {
		userNames = new ArrayList<>();
	}
	/**
	 * Receives a user name and adds it to the list of authorized users.
	 *  
	 * @param user User to be added to userNames if possible
	 */
	public void addUser(String user) {
		if(!userNames.contains(user)) {
			userNames.add(user);
		}
	}
	/**
	 * receives a user name and removes it from the list of authorized users. 
	 * 
	 * @param user Uesr to be removed from userNames if possible
	 */
	public void removeUser(String user) {
		if(userNames.contains(user)) {
			userNames.remove(userNames.indexOf(user));
		}
	}
	@Override
	public boolean canRead(User user) {
		if(userNames.contains(user.getUserName())) {
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		return "users named " + userNames.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		UserListAccessRule other = (UserListAccessRule)obj;
		if(!userNames.equals(other.userNames)) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return userNames.hashCode();
	}
}
