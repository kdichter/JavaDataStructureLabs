/**
 * Create a new class named GroupAccessRule, which represents a rule that says all members of a particular group may have access to a resource.
 * 
 * @author kevindichter
 *
 */
public class GroupAccessRule implements AccessRule{
	private String groupName;
	
	/**
	 * Creates a new GroupAccessRule object.
	 * 
	 * @param groupName Name of the group
	 */
	public GroupAccessRule(String groupName) {
		this.groupName = groupName;
	}
	@Override
	public boolean canRead(User user) {
		if(user.isInGroup(groupName)) {
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		return "members of group " + groupName;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		GroupAccessRule other = (GroupAccessRule)obj;
		if(!groupName.equals(other.groupName)) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return groupName.hashCode();
	}
}
