

import java.security.AccessControlException;
import java.util.HashMap;
import java.util.Scanner;

/**
 * A program that demonstrates the use of the classes from Lab 04.
 * 
 * @author Chad Hogg
 */
public class SecurityProgram {

	/**
	 * Runs the program.
	 * 
	 * @param args Not used.
	 */
	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		HashMap<String, Resource> resources = makeResources();
		HashMap<String, User> users = makeUsers();
		
		System.out.println("Users: ");
		for(User user : users.values()) {
			System.out.println("\t" + user);
		}
		System.out.print("Who are you?: ");
		String userName = console.nextLine();
		if(users.containsKey(userName)) {
			User user = users.get(userName);
			String choice;
			do {
				System.out.println();
				System.out.println("Resources: ");
				for(Resource resource : resources.values()) {
					System.out.println("\t" + resource);
				}
				System.out.print("Type the name of a resource to read it, or 'quit' to quit: ");
				choice = console.nextLine();
				if(resources.containsKey(choice)) {
					Resource resource = resources.get(choice);
					try {
						System.out.println();
						System.out.println("You read " + choice + ": " + resource.getContents(user));
						System.out.println();
					}
					catch(AccessControlException exception) {
						System.out.println(exception.getMessage());
					}
				}
				else if(!choice.equals("quit")) {
					System.out.println("There is no resource named '" + choice + "'.");
				}
			}
			while (!choice.equals("quit"));
		}
		else {
			System.out.println("Unknown user, exiting.");
		}
	}
	
	/**
	 * Gets a collection of resources associated with the Computer Science department.
	 * 
	 * @return A map of resource name -> resource object.
	 */
	private static HashMap<String, Resource> makeResources() {
		HashMap<String, Resource> resources = new HashMap<>();
		
		PublicAccessRule publicAccess = new PublicAccessRule();
		
		UserListAccessRule onlyKillian = new UserListAccessRule();
		onlyKillian.addUser("William Killian");
		
		UserListAccessRule oldsters = new UserListAccessRule();
		oldsters.addUser("Stephanie Schwartz");
		oldsters.addUser("Gary Zoppetti");
		oldsters.addUser("Nazli Hardy");
		
		UserListAccessRule newbies = new UserListAccessRule();
		newbies.addUser("Chris Cain");
		newbies.addUser("Jingnan Xie");
		newbies.addUser("Behrooz Etesamipour");
		
		GroupAccessRule faculty = new GroupAccessRule("faculty");
		
		GroupAccessRule compSci = new GroupAccessRule("computer science");
		
		GroupAccessRule infoTech = new GroupAccessRule("information technology");
		
		GroupAccessRule aiGroup = new GroupAccessRule("ai");
		
		resources.put("schedule", new Resource("schedule", "Details of when courses are offered.", publicAccess));
		resources.put("budget", new Resource("budget", "How we are spending money.", faculty));
		resources.put("evaluations", new Resource("evaluations", "Evaluations of junior faculty.", oldsters));
		resources.put("tutorials", new Resource("tutorials", "Learning how to do stuff.", newbies));
		resources.put("correspondence", new Resource("correspondence", "The personal emails of Will Killian.", onlyKillian));
		resources.put("answers", new Resource("answers", "Solutions to lab assignments.", faculty));
		resources.put("self-study", new Resource("self-study", "A document to get the CSCI program re-accredited.", compSci));
		resources.put("ideas", new Resource("ideas", "INTE curriculum proposals.", infoTech));
		resources.put("paper", new Resource("paper", "A paper the AI research group is working on.", aiGroup));

		return resources;
	}
	
	/**
	 * Gets a collection of users associated with the Computer Science department.
	 * 
	 * @return A map of user name -> user object.
	 */
	private static HashMap<String, User> makeUsers() {
		HashMap<String, User> users = new HashMap<>();
		User schwartz = new User("Stephanie Schwartz");
		schwartz.addToGroup("faculty");
		schwartz.addToGroup("computer science");
		schwartz.addToGroup("ai");
		users.put(schwartz.getUserName(), schwartz);
		User zoppetti = new User("Gary Zoppetti");
		zoppetti.addToGroup("faculty");
		zoppetti.addToGroup("computer science");
		users.put(zoppetti.getUserName(), zoppetti);
		User hardy = new User("Nazli Hardy");
		hardy.addToGroup("faculty");
		hardy.addToGroup("computer science");
		users.put(hardy.getUserName(), hardy);
		User killian = new User("William Killian");
		killian.addToGroup("faculty");
		killian.addToGroup("computer science");
		killian.addToGroup("ai");
		users.put(killian.getUserName(), killian);
		User hogg = new User("Chad Hogg");
		hogg.addToGroup("faculty");
		hogg.addToGroup("computer science");
		hogg.addToGroup("ai");
		users.put(hogg.getUserName(), hogg);
		User xie = new User("Jingnan Xie");
		xie.addToGroup("faculty");
		xie.addToGroup("computer science");
		users.put(xie.getUserName(), xie);
		User etesamipour = new User("Behrooz Etesamipour");
		etesamipour.addToGroup("faculty");
		etesamipour.addToGroup("information technology");
		users.put(etesamipour.getUserName(), etesamipour);
		User cain = new User("Chris Cain");
		cain.addToGroup("faculty");
		cain.addToGroup("computer science");
		users.put(cain.getUserName(), cain);
		return users;
	}
}
