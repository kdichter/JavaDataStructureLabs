import java.security.AccessControlException;

/**
 * Create a new class named Resource, which represents something that we wish to control access to.
 * @author kevindichter
 *
 */
public class Resource {
	private String resourceName;
	private String contents;
	private AccessRule accessRule;
	
	/**
	 * Constructs a new Resource object.
	 * 
	 * @param resourceName Name of the resource
	 * @param contents Contents of the resource
	 * @param accessRule Who is authorized to read this resource
	 */
	public Resource(String resourceName, String contents, AccessRule accessRule) {
		this.resourceName = resourceName;
		this.contents = contents;
		this.accessRule = accessRule;
	}
	/**
	 * Gets the resourceName.
	 * 
	 * @return resourceName
	 */
	public String getResourceName() {
		return resourceName;
	}
	/**
	 * Determines if user is able to have access to the contents.
	 * 
	 * @param user User to see if they can read the file
	 * @return the contents
	 */
	public String getContents(User user) {
		if(!accessRule.canRead(user)) {
			throw new AccessControlException("You do not have access.");
		}
		return contents;
	}
	@Override
	public String toString() {
		return resourceName + ", with hidden contents, accessible by " + accessRule.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		Resource other = (Resource)obj;
		if(!resourceName.equals(other.resourceName)) {
			return false;
		}
		if(!contents.equals(other.contents)) {
			return false;
		}
		if(!accessRule.equals(other.accessRule)) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return resourceName.hashCode() * 2 + contents.hashCode() * 4 + accessRule.hashCode() * 6;
	}
}
