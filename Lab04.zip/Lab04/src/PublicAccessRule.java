/**
 * Creates a new class named PublicAccessRule, which represents a rule that says all users may have access to a resource.
 * 
 * @author kevindichter
 *
 */
public class PublicAccessRule implements AccessRule{
	@Override
	public boolean canRead(User user) {
		return true; 
	}
	@Override
	public String toString() {
		return "anyone";
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		return 100;
	}
	
}
