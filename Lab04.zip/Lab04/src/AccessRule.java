/**
 * Create a new interface named AccessRule that will represent the ability to check whether or not a user is authorized to access a resource.
 * 
 * @author kevindichter
 *
 */
public interface AccessRule {
	
	/**
	 * Receives a User object and returns whether or not the user should be granted access.

	 * @param user User object 
	 * @return Whether or not the user should be granted access
	 */
	public abstract boolean canRead(User user);
}
