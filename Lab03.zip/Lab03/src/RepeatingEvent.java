import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Creates a RepeatingEvent, which is a subclass of Event.
 * 
 * @author Kevin Dichter
 */

public abstract class RepeatingEvent extends Event{
	//Stores stores the date of the first time the event occurs.
	private LocalDate firstOccurrence;
	//stores the number of times the event will repeat after the first time
	//This may be 0 to indicate that it repeats an infinite number of times. 
	//It may not be negative.
	private int repetitions;
	
	/**
	 * Constructs a new RepeatingEvent object.
	 * 
	 * @param eventName The name of the new event.
	 * @param startTime The time when the new event starts.
	 * @param endTime The time when the new event ends.  This must be after startTime.
	 * @param firstOccurrence The date of firstOccurrence of the event
	 * @param repetitions The number of times the event repeats
	 */
	public RepeatingEvent(String eventName, LocalDate firstOccurrence, int repetitions, LocalTime startTime, LocalTime endTime) {
		super(eventName, startTime, endTime);
		if(repetitions < 0) {
			throw new IllegalArgumentException("Can't have a negative amount of repetitions");
		}
		this.firstOccurrence = firstOccurrence;
		this.repetitions = repetitions;
	}
		
	/**
	 * returns the date of first Occurrence. 
	 * 
	 * @return the date of firstOccurrence
	 */
	public LocalDate getFirstOccurrence() {
		return firstOccurrence;
	}
	/**
	 * returns the number of repetitions. 
	 * 
	 * @return the repetitions
	 */
	public int getRepetitions() {
		return repetitions;
	}
	@Override
	public String toString() {
		if(repetitions == 0) {
			return super.toString() + "repeating for all";
		}
		return super.toString() + "repeating for " + repetitions;
		
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
		if(!super.equals(obj)) {
			return false;
		}
		RepeatingEvent other = (RepeatingEvent)obj;
		if(!firstOccurrence.equals(other.firstOccurrence)) {
			return false;
		}
		if(repetitions != other.repetitions) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		int firstInt = firstOccurrence.hashCode();
		return super.hashCode() + firstInt * 13 + repetitions * 15;
	}
	
}

