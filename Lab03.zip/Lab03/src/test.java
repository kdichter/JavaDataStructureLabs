import java.time.LocalDate;
import java.time.LocalTime;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WeeklyEvent m1 = new WeeklyEvent("Office Hours", LocalDate.of(2020, 8, 24), 15, LocalTime.of(15, 0), LocalTime.of(16, 50));
		WeeklyEvent m2 = new WeeklyEvent("Office Hours", LocalDate.of(2020, 8, 24), 15, LocalTime.of(15, 0), LocalTime.of(16, 50));
		System.out.println(m1.getFirstOccurrence());
		System.out.println(m2.getFirstOccurrence());
		System.out.println(m1.getRepetitions());
		System.out.println(m2.getRepetitions());
		if(m1.equals(m2)) {
			System.out.println("equal");
		}
		else {
			System.out.println("not equal");
		}
	}

}
