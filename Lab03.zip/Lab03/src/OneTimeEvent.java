import java.time.LocalDate;
import java.time.LocalTime;
/**
 * Creates a one time event, which is a subclass of event.
 * 
 * @author kevindichter
 *
 */
public class OneTimeEvent extends Event{
	//The date of the event
	private LocalDate date;
	
	/**
	 * Constructs a new OneTimeEvent object.
	 * 
	 * @param eventName The name of the new event.
	 * @param startTime The time when the new event starts.
	 * @param endTime The time when the new event ends.  This must be after startTime.
	 * @param date The date of the one time event.
	 */
	public OneTimeEvent(String eventName, LocalDate date, LocalTime startTime, LocalTime endTime) {
		super(eventName, startTime, endTime);
		this.date = date;
	}
	
	/**
	 * Determines whether or not the event occurs on a given day.
	 * 
	 * @param when The day it might occur on.
	 * @return True if the event occurs on that day, or false otherwise.
	 */
	public boolean isOnDay(LocalDate when) {
		if(when == null) {
			return false;
		}
		//year
		if(date.getYear() != when.getYear()) {
			return false;
		}
		//day
		else if(date.getDayOfMonth() != when.getDayOfMonth()) {
			return false;
		}
		//month
		else if(date.getMonthValue() != when.getMonthValue()) {
			return false;
		}
		else {
			return true;
		}
	}
	@Override
	public String toString() {
		return super.toString() + "on " + date;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null || this.getClass() != obj.getClass()) {
			return false;
		}
	    if(!super.equals(obj)) {
			return false;
		}
		OneTimeEvent other = (OneTimeEvent)obj;
		if(!date.equals(other.date)) {
			return false;
		}
		return true;
	}
	@Override
	public int hashCode() {
		int dateInt = date.hashCode();
		return super.hashCode() + dateInt * 11;
	}
}
