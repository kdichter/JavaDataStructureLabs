import java.time.LocalDate;
import java.time.LocalTime;

/**
 * 
 * Creates a monthly event, which is a subclass of RepeatingEvent.
 * 
 * @author kevindichter
 *
 */

public class WeeklyEvent extends RepeatingEvent{

	/**
	 * Constructs a new MonthlyEvent object.
	 * 
	 * @param eventName The name of the new event.
	 * @param startTime The time when the new event starts.
	 * @param endTime The time when the new event ends.  This must be after startTime.
	 * @param firstOccurrence The date of firstOccurrence of the event
	 * @param repetitions The number of times the event repeats
	 */
	public WeeklyEvent(String eventName, LocalDate firstOccurrence, int repetitions, LocalTime startTime, LocalTime endTime) {
		super(eventName, firstOccurrence, repetitions, startTime, endTime);
	}
	/**
	 * Checks if a date is on the same day of another WeeklyEvent.
	 * 
	 * @param when The day it might occur on.
	 * @return True if the event is on that day, it will need to be on the same 
	 * day of the week as the date of first occurrence, not before the first occurrence, 
	 * and (if there is a limited number of repetitions) not after the last repetition.
	 */
	public boolean isOnDay(LocalDate when) {
		if(when == null) {
			return false;
		}
		if(this.getFirstOccurrence().getDayOfWeek() != when.getDayOfWeek()) {
			return false;
		}
		if(when.isBefore(getFirstOccurrence())) {
			return false;
		}
		if(when.isAfter(getFirstOccurrence().plusWeeks(getRepetitions())) && getRepetitions() != 0) {
			return false;
		}
		return true;
	}
	@Override
	public String toString() {
		return super.toString() + " weeks starting on " + this.getFirstOccurrence();
	}
}
