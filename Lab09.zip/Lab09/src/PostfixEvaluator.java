import java.util.EmptyStackException;
import java.util.Stack;

/**
 * Evaluates a postfix expression.
 * 
 * @author kevindichter
 *
 */
public class PostfixEvaluator {
	
	/**
	 * Evaluates a postfix mathematical expression.
	 * 
	 * @param input A String containing the expression.
	 * @return A String containing the values of the expression, or an error message if there was a problem.
	 */
	public static String evaluate(String input) {
		Stack<Double> stack = new Stack<>();
		TokenScanner line = new TokenScanner(input);
		if(isEmpty(input)) {
			return "No input.";
		}
		while(line.hasNextToken()) {
			Token element = line.nextToken();
			if(element.isLeftParen()) {
				return "( has no meaning here.";
			}
			else if(element.isRightParen()) {
				return ") has no meaning here.";
			}
			else if(element.isNumber()) {
				stack.push(element.getNumberValue());
			}
			else if(element.isOperator()) {
				try {
					operation(stack, element.getSymbol());
				}
				catch(EmptyStackException exception) {
					return "Stack underflow.  Not enough operands on stack.";
				}
			}
		}
		try {
			new Token(input.substring(input.length() - 1));
		}
		catch(IllegalArgumentException exception) {
			return "Computed answer, but not all input used.";
		}
		
		if(stack.size() > 1) {
			return "Computed answer, but values remain on stack.";
		}
		return "" + stack.pop();
	}
	
	/**
	 * Checks a line of input to see if it's empty.
	 * 
	 * @param line Line of input to be checked.
	 * @return True if the line is empty, false otherwise.
	 */
	private static boolean isEmpty(String input) {
		//boolean isEmpty = true;
		TokenScanner line = new TokenScanner(input);
		while(line.hasNextToken()) {
			Token element = line.nextToken();
			if(element.isNumber() || element.isOperator() ||
				element.isLeftParen() || element.isRightParen()) {
				return false;
				//isEmpty = false;
				//break;
			}
		}
		return true;
		/*
		if(isEmpty) {
			throw new EmptyStackException();
		}
		*/
	}
	
	/**
	 * Pops two numbers off the stack, performs an operation on them, then pushes the result back onto the stack.
	 * 
	 * @param stack The stack in which the numbers are first popped off, then pushed back onto.
	 * @param symbol The symbol that determines the operation.
	 */
	private static void operation(Stack<Double> stack, char symbol) {
		double firstNum = stack.pop();
		double lastNum = stack.pop();
		if(symbol == '+') {
			stack.push(firstNum + lastNum);
		}
		else if(symbol == '-') {
			stack.push(lastNum - firstNum);
		}
		else if(symbol == '*') {
			stack.push(firstNum * lastNum);
		}
		else {
			stack.push(lastNum / firstNum);
		}
		
	}
}
