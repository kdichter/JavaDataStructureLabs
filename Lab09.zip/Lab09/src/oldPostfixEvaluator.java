import java.util.EmptyStackException;
import java.util.Stack;

/**
 * Evaluates a postfix expression.
 * 
 * @author kevindichter
 *
 */
public class oldPostfixEvaluator {
	/**
	 * Evaluates a postfix mathematical expression.
	 * 
	 * @param input A String containing the expression.
	 * @return A String containing the values of the expression, or an error message if there was a problem.
	 */
	public static String evaluate(String input) {
		Stack<Double> stack = new Stack<>();
		TokenScanner line = new TokenScanner(input);
		/*
		try {
			isEmpty(input);
		}
		catch(EmptyStackException exception) {
			return "No input.";
		}
		*/
		int parenResult = hasParentheses(input);
		if(parenResult == 1) {
			return "( has no meaning here.";
		}
		else if(parenResult == 2) {
			return  ") has no meaning here.";
		}
		if(isEmpty(input)) {
			return "No input.";
		}
		while(line.hasNextToken()) {
			Token element = line.nextToken();
			if(element.isNumber()) {
				stack.push(element.getNumberValue());
			}
			else if(element.isOperator()) {
				try {
					operation(stack, element.getSymbol());
				}
				catch(EmptyStackException exception) {
					return "Stack underflow.  Not enough operands on stack.";
				}
			}
		}
		String last = input.substring(input.length() - 1);
		if(stack.size() == 1 && input.length() > 3 && !last.equals("+") && !last.equals("-") &&
				!last.equals("*") && !last.equals("/")) {
			return "Computed answer, but not all input used.";
		}
		if(stack.size() > 1) {
			return "Computed answer, but values remain on stack.";
		}
		return "" + stack.pop();
	}
	
	/**
	 * Checks a line of input to see if it's empty.
	 * 
	 * @param line Line of input to be checked.
	 * @return True if the line is empty, false otherwise.
	 */
	private static boolean isEmpty(String input) {
		//boolean isEmpty = true;
		TokenScanner line = new TokenScanner(input);
		while(line.hasNextToken()) {
			Token element = line.nextToken();
			if(element.isNumber() || element.isOperator()) {
				return false;
				//isEmpty = false;
				//break;
			}
		}
		return true;
		/*
		if(isEmpty) {
			throw new EmptyStackException();
		}
		*/
	}
	
	/**
	 * Checks a line of input for parentheses, false otherwise.
	 * 
	 * @param line Line of input to be checked.
	 * @return 1 if (, 2 if ), or 0 if no parenthesis .
	 */
	private static int hasParentheses(String input) {
		TokenScanner line = new TokenScanner(input);
		while(line.hasNextToken()) {
			Token element = line.nextToken();
			if(!element.isNumber()) {
				if(element.getSymbol() == '(') {
					return 1;
				}
				else if(element.getSymbol() == ')') {
					return 2;
				}
			}
		}
		return 0;
	}
	
	/**
	 * Pops two numbers off the stack, performs an operation on them, then pushes the result back onto the stack.
	 * 
	 * @param stack The stack in which the numbers are first popped off, then pushed back onto.
	 * @param symbol The symbol that determines the operation.
	 */
	private static void operation(Stack<Double> stack, char symbol) {
		double firstNum = stack.pop();
		double lastNum = stack.pop();
		if(symbol == '+') {
			stack.push(firstNum + lastNum);
		}
		else if(symbol == '-') {
			stack.push(lastNum - firstNum);
		}
		else if(symbol == '*') {
			stack.push(firstNum * lastNum);
		}
		else {
			stack.push(lastNum / firstNum);
		}
		
	}
}

