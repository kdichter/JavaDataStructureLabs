import org.junit.Test;
import org.junit.runners.MethodSorters;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.FixMethodOrder;


/*
 * You must include the Junit4 library to use this test unit.
 * 
 * The simple way to add it is to hover your mouse over one of the @Test annotations below 
 *   and accept Eclipse's offer to fix the problem by adding JUnit4 to the build path.
 *
 * The long way is to select the project and then choose Properties... from the File menu.
 * Click on "Java Build Path" in the panel at the left.
 * Select Libraries from the list at the top.
 * Select Add Library... from the right side of the panel.
 * Select JUnit and click on Next.
 * Change the version to JUnit 4 and click on Finish.
 * Click on OK in the properties panel.
 * 
 * You can then run these tests using "Run As JUnit Test" instead of "Runs As Java Application".
 */


/**
 * JUnit tests for SortedList.
 *
 * @author Chad Hogg, Kevin Dichter
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SortedListTests {

	/**
	 * Creates a default SortedList and confirms that it was initialized correctly.
	 */
	@Test
	public void test01Constructor() {
		SortedList list = new SortedList();
		assertEquals("New list had wrong size.", 0, list.size());
		assertEquals("New list toString was wrong.", "( )", list.toString());
	}

	/**
	 * Inserts one element into a SortedList.
	 */
	@Test
	public void test02InsertOne() {
		SortedList list = new SortedList();
		list.insert(4.0);
		assertEquals("Inserting 4.0 to empty list yielded wrong size.", 1, list.size());
		assertEquals("Inserting 4.0 to empty list yielded wrong string.", "( 4.0 )", list.toString());
	}
	
	/**
	 * Inserts more than one element into a SorttedList in order.
	 */
	@Test
	public void test03InsertMoreThanOneInOrder() {
		SortedList list = new SortedList();
		list.insert(4.0);
		list.insert(5.0);
		assertEquals("Inserting 4.0 and 5.0 to empty list yielded wrong size.", 2, list.size());
		assertEquals("Inserting 4.0 and 5.0 to empty list yielded wrong string.", "( 4.0 5.0 )", list.toString());
	}
	
	/**
	 * Inserts two elements into a SorttedList out of order.
	 */
	@Test
	public void test04InsertTwoOutOfOrder() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(4.0);
		assertEquals("Inserting 5.0 and 4.0 to empty list yielded wrong size.", 2, list.size());
		assertEquals("Inserting 5.0 and 4.0 to empty list yielded wrong string.", "( 4.0 5.0 )", list.toString());
	}
	
	/**
	 * Inserts three elements into a SorttedList out of order.
	 */
	@Test
	public void test05InsertThreeOutOfOrder() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(3.0);
		list.insert(4.0);
		assertEquals("Inserting 5.0, 3.0, and 4.0 to empty list yielded wrong size.", 3, list.size());
		assertEquals("Inserting 5.0, 3.0, and 4.0 to empty list yielded wrong string.", "( 3.0 4.0 5.0 )", list.toString());
	}
	
	/**
	 * Finds the index of a value that is included in the list.
	 */
	@Test
	public void test06SearchesListAndFindsIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(3.0);
		list.insert(4.0);
		double value = 3.0;
		list.find(value);
		
		assertEquals("Finding the value of 3.0 yielded the wrong index.", 0, list.find(value));
	}
	
	/**
	 * Finds the index of a value that is not included in the list.
	 */
	@Test
	public void test07SearchesListAndDoesNotFindIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(3.0);
		list.insert(4.0);
		double value = 1.0;
		list.find(value);
		
		assertEquals("Finding the value 1.0 in the SortedList ( 3.0 4.0 5.0 ) yielded the wrong index.", -1, list.find(value));
	}
	
	/**
	 * Removes at an index that is negative of an array.
	 */
	@Test
	public void test08removeAtNegativeIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.removeAt(-1);
		
		assertEquals("Removing at an index of -1 yielded true.", false, list.removeAt(-1));
	}
	
	/**
	 * Removes at an index that is the size of the array.
	 */
	@Test
	public void test09removeAtIllegalSizeIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.removeAt(1);
		
		assertEquals("Removing at an index of 1 for SortedList ( 5.0 ) with length 1 yielded true.", false, list.removeAt(1));
	}
	
	/**
	 * Remove at an index within the bounds of an array.
	 */
	@Test
	public void test10removeAtEmptyArray() {
		SortedList list = new SortedList();
		list.removeAt(0);
		
		assertEquals("Removing at an index of an empty array yielded false.", false, list.removeAt(0));
	}
	
	/**
	 * Remove at an index within the bounds of an array.
	 */
	@Test
	public void test11removeAtFirstlIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(6.0);
		list.removeAt(0);
		
		assertEquals("Removing at the first index of the SortedList ( 5.0 6.0 ) list yielded the wrong string.", "( 6.0 )", list.toString());
	}
	
	/**
	 * Remove at an index at the beginning of an array.
	 */
	@Test
	public void test12removeAtMiddleIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(6.0);
		list.insert(7.0);
		list.removeAt(list.size() / 2);
		
		assertEquals("Removing at the middle index of the SortedList ( 5.0 6.0 7.0 ) list yielded the wrong string.", "( 5.0 7.0 )", list.toString());
	}
	
	/**
	 * Remove at an index at the end of an array.
	 */
	@Test
	public void test13removeAtLastlIndex() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(6.0);
		list.removeAt(list.size() - 1);
		
		assertEquals("Removing at the last index of the SortedList ( 5.0 6.0 ) yielded the wrong string.", "( 5.0 )", list.toString());
	}
	
	/**
	 * Remove at an index from within a large list.
	 */
	@Test
	public void test14removeElementFromLargeList() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.insert(6.0);
		list.insert(7.0);
		list.insert(8.0);
		list.insert(9.0);
		list.removeAt(2);
		
		assertEquals("Removing an element from the SortedList ( 5.0 6.0 7.0 8.0 9.0) yielded the wrong string.", "( 5.0 6.0 8.0 9.0 )", list.toString());
	}
	
	/**
	 * Remove the last element remaining in a list.
	 */
	@Test
	public void test15removeLastRemainingElement() {
		SortedList list = new SortedList();
		list.insert(5.0);
		list.removeAt(0);
		
		assertEquals("Removing the last element from the SortedList ( 5.0 ) yielded the wrong string.", "( )", list.toString());
	}
	
	//REWATCH THE MAPS VIDEO FOR THE DIFFERENCE BETWEEN HASHMAP AND TREEMAP

	
	
	
	
	
	

	
}
