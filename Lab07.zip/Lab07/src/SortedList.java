
//import SortedList.Node;

/**
 * A class that stores a list of doubles, keeping them in numerical order at all times.
 * 
 * @author Beth Katz, Chad Hogg
 *
 */
public class SortedList {

	/**
	 * A node in a sorted list.
	 * 
	 * @author Chad Hogg
	 */
	private static class Node {
		/** The number stored in this node. */
		public double value;
		/** A reference to the node that comes after this one (null if none). */
		public Node next;
		
		/**
		 * Constructs a new Node.
		 *
		 * @param value The number to store in the new node.
		 * @param next The node that should come after the new one.
		 */
		public Node(double value, Node next) {
			this.value = value;
			this.next = next;
		}
	}

	// Class Invariant:
	// WRITE YOUR OWN CLASS INVARIANT HERE	

	/** The first node of this list, or null if there is none. */
	private Node head;
	/** The number of nodes in this list. */
	private int listLength;
	
	/**
	 * Constructs a new, empty list.
	 * 
	 * @postcondition This list has no nodes.
	 */
	public SortedList() {
		head = null;
		listLength = 0;
	}
	
	/**
	 * Inserts a new value into this list, maintaining the sorted order.
	 * 
	 * @param value The value to add.
	 * @postcondition The new value has been added to the list, after all
	 *   elements that are smaller than it and before all elements that are
	 *   greater than it.
	 */
	public void insert(double value) {
		if(head == null) {
			head = new Node(value, null);
		}
		else {
			Node previous = getPrecedingNode(value);
			if(previous == null) {
				Node node = new Node(value, head);
				head = node;
			}
			else {
				Node node = new Node(value, previous.next);
				previous.next = node;
			}
		}
		listLength++;
	}

	/**
	 * Gets the node that would come before the new one created to hold a
	 *   value (also known as the last node that contains a number less than the
	 *   value).
	 * 
	 * @param value A value that is going to be inserted.
	 * @return The last node that contains a number less than the value, or null
	 *   if no nodes contain numbers less than the value.
	 */
	private Node getPrecedingNode(double value) {
		Node current = head;
		if(listLength == 0 || current.value > value) {
			return null;
		}
		for(int i = 0; i < listLength - 1; i++) { 
			if(current.next.value > value) {
				return current;
			}
			current = current.next;
		}
		return current;
	}

	/**
	 * Searches this list for a value.
	 * 
	 * @param value A number to search for.
	 * @return The first position at which that value appears (0 = first node,
	 *   1 = second node, ...) or -1 if it not found anywhere.
	 */
	public int find(double value) {
		Node current = head;
		for(int i = 0; i < listLength; i++) {
			if(current.value == value) {
				return i;
			}
			current = current.next;
		}
		return -1;
	}

	/**
	 * Removes a node from this list.
	 * 
	 * @param index The position of the node to remove (0 = first node, 1 = second
	 *   node, ...).
	 * @return Whether or not such a node exists.  (True if 0 <= index < size().)
	 * @postcondition If there was a node at that position, it has been removed.
	 */
	public boolean removeAt(int index) {
		if(index < 0 || index >= listLength) {
			return false;
		}
		if(index == 0) {
			if(listLength == 1) {
				head = null;
			}
			else {
				head = head.next;
			}
			
		}
		else {
			Node previous = head;
			for(int i = 0; i < index - 1; i++) {
				previous = previous.next;
			} 
			previous.next = previous.next.next;
		}
		listLength--;
		return true;
	}

	/**
	 * Gets the number of elements in this list.
	 * 
	 * @return The number of elements in this list.
	 */
	public int size() {
		return listLength; // TODO: Fill in body.
	}
	
	/**
	 * Gets a String representing this list.
	 * 
	 * @return A String like "( 2.0 4.0 5.0 )".
	 */
	@Override
	public String toString() {
		String answer = "( ";

		for(Node current = head; current != null; current = current.next) {
			answer += current.value + " ";
		}
		answer += ")";
		return answer;
	}
}
