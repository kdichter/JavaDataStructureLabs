/**
 * Evaluates a prefix mathematical expression.
 * 
 * @author kevindichter
 *
 */
public class PrefixEvaluator {
	
	/**
	 * Evaluates a prefix mathematical expression.
	 * 
	 * @param input A String containing the expression.
	 * @return A String containing the value of the expression, or an error message if there was a problem.
	 */
	public static String evaluate (String input) {
		TokenScanner lineTemp = new TokenScanner(input);
		if(lineTemp.hasNextToken() == false) {
			return "No input.";
		}
		int numCount = 0;
		int operatorCount = 0;
		while(lineTemp.hasNextToken()) {
			Token token = lineTemp.nextToken();
			if(token.isLeftParen()) {
				return "( has no meaning here.";
			}
			else if(token.isRightParen()) {
				return ") has no meaning here.";
			}
			else if(token.isNumber()) {
				numCount++;
			}
			else if(token.isOperator()) {
				operatorCount++;
			}
		}
		if(numCount == operatorCount) {
			return "Not enough operands.";
		}
		if(numCount - 1 != operatorCount || !lineTemp.reachedEnd()) {
			return "Computed answer, but not all input used.";
		}
		TokenScanner line = new TokenScanner(input);
		return "" + evaluateSub(line);
	}
	
	/**
	 * Evaluates the next sub-expression found in a scanner.
	 * 
	 * @param scanner A TokenScanner containing at least one prefix expression.
	 * @return The result of the first sub-expression found in the scanner.
	 */
	private static Double evaluateSub(TokenScanner scanner) {
		if(scanner.hasNextToken()) {
			Token token = scanner.nextToken();
			if(token.isOperator()) {
				if(token.getSymbol() == '+') {
					return evaluateSub(scanner) + evaluateSub(scanner);
				}
				else if(token.getSymbol() == '-') {
					return evaluateSub(scanner) - evaluateSub(scanner);
				}
				else if(token.getSymbol() == '*') {
					return evaluateSub(scanner) * evaluateSub(scanner);
				}
				else if(token.getSymbol() == '/') {
					return evaluateSub(scanner) / evaluateSub(scanner);
				}
				
			}
			else if(token.isNumber()) {
				return token.getNumberValue();
			}
		}
		return 0.0;
	}
}
